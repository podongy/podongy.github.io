#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid > 0) {
        printf("Parent process starts (PID:%d)\n",getpid());
        sleep(3);
        printf("Parent process ends (PID:%d)\n",getpid());
    } else if (pid == 0) {
        printf("Child process starts (PID:%d)\n",getpid());
        pid = fork();
        if (pid == 0) {
            sleep(0.5);
            execl("/bin/ps", "ps", "j", NULL);
        }
        printf("Child process ends (PID:%d)\n",getpid());
    }
}

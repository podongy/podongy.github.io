#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        printf("(Child) PID: %d)\n", getpid());
        sleep(10);
        printf("(Child) Finished\n");
    }
    else {
        printf("(Parent)Finished (PID: %d)\n", getpid());
        exit(0); 
    }

    return 0;
}


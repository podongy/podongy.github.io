#include <stdio.h>
#include <string.h>

void main() {
    char buffer[100];

    printf("(Child) Enter a string: ");
    fgets(buffer, sizeof(buffer), stdin);
    printf("(Child) You entered: %s\n", buffer);
}


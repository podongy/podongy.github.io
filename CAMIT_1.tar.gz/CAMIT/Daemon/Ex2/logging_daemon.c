#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>

void log_file_content() {
    char file_content[1024] = {0};
    system("touch /tmp/input.txt");

    // Daemon loop
    while (1) {
        FILE *file = fopen("/tmp/input.txt", "r");









    }
}

void main() {
    if (daemon(0, 0) == -1) {
        perror("daemon");
        exit(EXIT_FAILURE);
    }

    openlog("FileLoggerDaemon", LOG_PID, LOG_DAEMON);
    syslog(LOG_INFO, "Logging Daemon started.");

    log_file_content();

    closelog();
}

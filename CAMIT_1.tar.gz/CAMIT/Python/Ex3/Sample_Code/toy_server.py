import socket
import sys

html_content = """
<!DOCTYPE html>
<html>
<head></head>
<body><h1>Welcome to My Toy Server</h1></body>
</html>
"""

if len(sys.argv) != 2:
  print("Usage: python toy_server.py <HOST_IP>")
  sys.exit(1)

HOST_IP = sys.argv[1]
port = 8000

# Create a socket object using TCP (SOCK_STREAM)
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the specified host and port
server_socket.bind((HOST_IP, port))

# Enable the server to accept connections (make it a listening socket)
server_socket.listen(1)
print(f"Server listening on {HOST_IP}:{port}")

# Wait for a client connection
client_connection, client_address = server_socket.accept()
print(f"Connected by {client_address}")

# Receive the request from the client
request = client_connection.recv(1024).decode()
print("Request:")
print(request)

# Prepare the HTTP response
response = f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n{html_content}"

# Send the HTTP response to the client
client_connection.sendall(response.encode())

# Close the connection
client_connection.close()

server_socket.close()

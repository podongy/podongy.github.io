# Open the CSV file
with open('example.csv', 'r') as file:
    # Read all lines from the file
    lines = file.readlines()

    # Get the headers by splitting the first line
    headers = lines[0].strip().split(',')

    # Iterate through the remaining lines and create a dictionary for each row












# Open the CSV file
with open('example.csv', 'r') as file:
    # Read all lines from the file
    lines = file.readlines()

    # Get the headers by splitting the first line
    headers = lines[0].strip().split(',')

    # Iterate through the remaining lines and create a dictionary for each row
    for line in lines[1:]:
        values = line.strip().split(',')
        line_str = ""

        for i in range(len(headers)):
            line_str += headers[i]+":"+values[i]+" "

        print(line_str)

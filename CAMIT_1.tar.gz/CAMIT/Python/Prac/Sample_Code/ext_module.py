import pyfiglet

ascii_art = pyfiglet.figlet_format("Hello!")
print(ascii_art)


with open("input.txt", 'r') as infile:
    lines = infile.readlines()

    with open("output.txt", 'w') as outfile:
        for line in lines:
            line = line.strip()
            if line.isdigit():
                output = int(line) * 2
            else:
                output = f"{line * 2}"
            outfile.write(f"{output}\n")

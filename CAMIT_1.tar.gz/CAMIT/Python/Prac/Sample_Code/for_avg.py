# Dictionary containing students and their grades
students_grades = {
    "Alice": 85,
    "Bob": 90,
    "Charlie": 78,
    "David": 92
}

# Initialize total to 0 for calculating the sum of grades
total = 0

# Using a for loop to iterate over the dictionary and calculate the total
for grade in students_grades.values():
    total += grade

# Calculate average grade
average = total / len(students_grades)

for student, grade in students_grades.items():
    print(f"{student}: {grade}")
print(f"Average grade: {average:.2f}")

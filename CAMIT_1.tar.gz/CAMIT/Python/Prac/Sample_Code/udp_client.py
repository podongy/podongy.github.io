import socket
import sys

# Check if the port argument is provided
if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <port>")
    sys.exit(1)

# Get the port number from the command line argument
port = int(sys.argv[1])

# Create a UDP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Send data to the packet server at the given port
server_address = ('localhost', port)

# Send multiple messages
for i in range(100):
    message = f"{i}: Hello, UDP Server!"
    client_socket.sendto(message.encode(), server_address)
    print(f"(Client) Sent message {i}")

# Close the socket
client_socket.close()


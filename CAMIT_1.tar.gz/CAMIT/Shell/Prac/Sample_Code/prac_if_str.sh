#!/bin/bash

str1=$1
str2=$2

if [ -z $str1 ] || [ -z $str2 ]; then
    echo "Two strings are needed"
    exit 0
fi

if [ $str1 = $str2 ]; then
    echo "Strings are equal"
else
    echo "Strings are different"
fi

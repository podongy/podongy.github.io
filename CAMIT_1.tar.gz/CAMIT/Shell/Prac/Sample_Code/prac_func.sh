#!/bin/bash

check_multiple_of_three() {
    local number=$1

    if [ $((number % 3)) -eq 0 ]; then
        echo "$number is a multiple of 3."
    else
        echo "$number is not a multiple of 3."
    fi
}

check_multiple_of_three $1

#!/bin/bash

echo "Script name: $0"
echo "Number of arguments: $#"
echo "First argument: $1"
echo "All arguments: $*"
echo "Process ID of the script: $$"

sleep 5 &
echo "Background process ID: $!"

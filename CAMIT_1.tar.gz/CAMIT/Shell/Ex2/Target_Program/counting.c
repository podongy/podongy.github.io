#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main() {
    srand(time(0)); // Initialize random number generator
    int run_time = rand() % 10 + 1; // Random time between 1 and 10 seconds
    pid_t pid = getpid();

    printf("Program : for up to %d seconds with PID = %d.\n", run_time, pid);

    for (int i = 1; i <= run_time; i++) {
        printf("Program : running(%d)... Count: %d\n", pid, i);
        sleep(1); // Print the count every second
    }

    printf("Program : finished after %d seconds with PID = %d.\n", run_time, pid);
    return 0;
}


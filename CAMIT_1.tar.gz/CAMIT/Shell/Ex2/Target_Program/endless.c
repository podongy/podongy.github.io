#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main() {
    srand(time(0)); // Initialize random number generator
    int i = 0;
    FILE *file = fopen("endless.log", "w");

    printf("Program : starts\n");
    for (i=0;i<20;i++) {
    	printf("Program : running... Count: %d\n", i);
    	fprintf(file, "Program : running... Count: %d\n", i);
	int error_level = rand() % 5;
	switch(error_level) {
	     case 0: 
    		printf("Program : Info message\n");
    		fprintf(file, "Program : Info message\n");
		break;
	     case 1: 
    		printf("Program : Warning message\n");
    		fprintf(file, "Program : Warning message\n");
		break;
	     case 2: 
    		printf("Program : Error message\n");
    		fprintf(file, "Program : Error message\n");
		break;
	}
	fflush(stdout);
	fflush(file);
        sleep(1); 
    }
    printf("Program : Error message\n");
    fprintf(file, "Program : Error message\n");

    fclose(file);
    return 0;
}

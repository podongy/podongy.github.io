#!/bin/bash

TARGET_DIR="./Target_Program"
PROGRAM_NAME="counting"

# Monitor loop
while true; do
    # Check if the program is running using pgrep
    if pgrep -x "$PROGRAM_NAME" > /dev/null; then
        echo "Shell - Program is still running"
    else
        echo "Shell - Program stopped. Restarting..."
	# Start the program in the background
    	$TARGET_DIR/$PROGRAM_NAME &      
    fi
    
    sleep 3  # Check every 3 seconds
done

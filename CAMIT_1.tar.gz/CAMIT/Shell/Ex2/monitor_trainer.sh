#!/bin/bash

TARGET_PROGRAM="./Target_Program/endless"
LOG_FILE="endless.log"

echo "Starting the target program..."

PID=$!   # Get the process ID of the target program
echo "Target program started with PID $PID."

# Monitor the log file for 'Error' messages
while true; do
    if 
        echo "Stopping the target program (PID: $PID)..."
        
        break
    fi
    sleep 2   # Check the log every 2 seconds
done

ERROR_COUNT=
WARNING_COUNT=
INFO_COUNT=

echo "================= Statistics ================"
echo "Count of 'Error' messages: $ERROR_COUNT"
echo "Count of 'Warning' messages: $WARNING_COUNT"
echo "Count of 'Info' messages: $INFO_COUNT"


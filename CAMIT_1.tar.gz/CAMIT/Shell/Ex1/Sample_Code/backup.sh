#!/bin/bash
# Set the source and destination directories
SOURCE_DIR="./SOURCE"
DEST_DIR="./BACKUP"

# Create a backup file with the current date
DATE=$(date +%Y%m%d)
BACKUP_FILE="backup_$DATE.tar.gz"

# Create the backup file
tar -czf $DEST_DIR/$BACKUP_FILE $SOURCE_DIR

# Print completion message
echo "Backup completed: $DEST_DIR/$BACKUP_FILE"

#include <stdio.h>

void main() {
	printf("CAMIT Hello!\n");
}
